class Adresse {
    private String strasseHausnr;
    private String plz;
    private String ort;

    public Adresse(String strasseHausnr, String plz, String ort) {
        this.strasseHausnr = strasseHausnr;
        this.plz = plz;
        this.ort = ort;
    }
}
